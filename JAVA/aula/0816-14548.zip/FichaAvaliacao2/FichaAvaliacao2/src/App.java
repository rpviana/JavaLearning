import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class App {
    public static void main(String[] args) throws Exception {
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy/MM/dd");
       
        /**Carro carro1 = new Carro("33-VP-45", LocalDate.parse("2001/06/12", formato), "bmw", "x6", 4, 5.20, "gasoleo", 150000);
        Carro carro2 = new Carro("33-VP-46", LocalDate.parse("2015/06/12", formato), "Opel", "Astra", 4, 7.20, "diesel", 30000);
        Carro carro3 = new Carro("33-VP-47", LocalDate.parse("2024/06/12", formato), "Maserati", "SV6", 4, 15.20, "hibrido", 15);
        Carro carro4 = new Carro("33-VP-48", LocalDate.parse("1955/06/12", formato), "Ferrari", "LaFerrari", 4, 0, "gasoleo", 70000);
        Mota mota1 = new Mota("33-VP-48", LocalDate.parse("2009/06/12", formato), "ducati", "c4", 4, 0, "gasoleo", 70000);
        Mota mota2 = new Mota("33-VP-48", LocalDate.parse("1989/06/12", formato), "kawasaki", "5", 4, 0, "gasoleo", 70000);**/
    }
}
